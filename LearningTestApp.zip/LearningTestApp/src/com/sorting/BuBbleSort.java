package com.sorting;

public class BuBbleSort {
	
	public int[] bubbleSort(int[] a) {
		int n=a.length;
		for(int i=0;i<n-1;i++) {
			if(a[i]>a[i+1]) {
				int temp=a[i+1];
				a[i+1]=a[i];
				a[i]=temp;
			}
		}
		return a;
	}
	
	public static void main(String args[]) {
		int[]a= {15,2,3,6,7,8};
		BuBbleSort bs = new BuBbleSort();
		int[]b=bs.bubbleSort(a);
		for(int i=0;i<b.length;i++) {
			System.out.print(","+b[i]);
		}
	}

}
