package com.sorting;

public class MergeSort {
	
	int[]a= {10,5,3,4,5,2,11,3,64};
	
	public void mergerSort() {
		
	}
	
	public void mergeParti(int[] a) {
		int n= a.length;
		int mid = n/2;
		int nl=mid;
		int nr= n-mid;
		int[] lArry = new int[nl];
		int[] rArry= new int[nr];
		int i=0,j=0,k=0;
		
		for(i=0;i<nl;i++) {
			lArry[i]=a[i];
		}
		
		for(j=0;j<nl;j++) {
			rArry[j]=a[j];
		}
		
		while(i<=nl && j<=nr) {
			if(n<2) {
				return;
			}
			if(lArry[i]<rArry[j]) {
				a[k]=lArry[i];
				i++;
				k++;
			}else {
				a[k]=rArry[j];
				j++;
				k++;
			}
			
		}
	}

}
