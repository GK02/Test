package com.sorting;

public class SelectionSortDemo {
	//int{4,2,5,7,8}
	public int[] selectionSort(int[]input) {
	
		 int inputLength = input.length;

	        for (int i = 0; i < inputLength - 2; i++) {

	            int min = i;

	            // find the first, second, third, fourth... smallest value
	            for (int j = i + 1; j < inputLength; j++) {
	                if (input[j] < input[min]) {
	                    min = j;
	                }
	            }

	            // swaps the smallest value with the position 'i'
	            int temp = input[i];
	            input[i] = input[min];
	            input[min] = temp;

	            //next pls
	        }
		
		return input;
		
	}
	
	public static void main(String args[]) {
		int[] a={4,2,5,7,8};
		SelectionSortDemo ss= new SelectionSortDemo();
		int[]b=ss.selectionSort(a);
		for(int i=0;i<b.length;i++) {
			System.out.print(b[i]);
		}
	
	}
	

}
