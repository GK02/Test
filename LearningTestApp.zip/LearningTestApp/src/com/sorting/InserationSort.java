package com.sorting;

public class InserationSort {
	
	public int[] inserationSort(int[]a) {
		
		int n=a.length;
		
		for(int i=1;i<n;i++) {
			int value=a[i];
			int hole=i;
			while(hole>0 && a[hole-1]>value) {
				a[hole]=a[hole-1];
				hole=hole-1;
			}
			a[hole]=value;
		}
		
		return a;
	}
	
	public static void main(String args[]) {
		int[] a= {7,2,5,8,3};
		InserationSort in = new InserationSort();
		int[]b=in.inserationSort(a);
		for(int i=0;i<=b.length-1;i++) {
			System.out.print(","+b[i]);
		}
	}

}
