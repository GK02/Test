package com.matrix;

public class MatrixMultiplication {
	
	
	public static void main(String args[]) {
		
		int m1[][]= {{1,2,3},
				 {4,5,6}};
		int m2[][]= {{6,7},
				 {8,9},
				 {10,11}};
		int result[][]= new int[2][2];
		
		for(int i=0;i<m1.length;i++) {
			for(int j=0;j<3;j++) {
				for(int k=0;k<2;k++) {
					result[i][k]+=m1[i][k]*m1[k][j];
				}
			}
			System.out.println();
		}
		
		System.out.println(m1.length);
		for(int i=0;i<m1.length;i++) {
			for(int j=0;j<2;j++) {
				System.out.print(result[i][j]+",");
			}
			System.out.println();
		}
		
		/*for(int i=0;i<m2.length;i++) {
			for(int j=0;j<2;j++) {
				System.out.print(m2[i][j]+",");
			}
			System.out.println();
		}*/
	}
}
