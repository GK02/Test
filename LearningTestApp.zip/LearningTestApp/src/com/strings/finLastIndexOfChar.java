package com.strings;

public class finLastIndexOfChar {
	
	public static void main(String args[]) {
		String st ="Jeevan";
		finLastIndexOfChar ff = new finLastIndexOfChar();
		int kk=ff.findLastIndexchar(st, 'n');
		System.out.println("the last index of E is::"+kk);
	}
	
	public int findLastIndexchar(String str,char x) {
		int i;
		int len=str.length();
		for(i=len-1;i>=0;i--) {
			char ch = str.charAt(i);
			if(ch==x) {
				return i;
			}
		}
		return -1;
	}

}
