package com.learning;

public class ReverseStringUsingStack {
	
	
	public String reverseString(String word) throws Exception {
		StringBuilder sb = new StringBuilder();
		int sizeOfStack = word.length();
		StackImpl<Character> st= new StackImpl<Character>(sizeOfStack);
		for(int i=0;i<sizeOfStack;i++) {
			char ch = word.charAt(i);
			st.push(ch);
		}
		
		while(!st.isEmpty()) {
			sb.append(st.pop());
		}
		
		return sb.toString();
	}
	
	public static void main(String args[]) {
		ReverseStringUsingStack rs = new ReverseStringUsingStack();
		try {
			String reverseStr=rs.reverseString("Jeevan Borale");              
			System.out.println("the reversed string is ::"+reverseStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
