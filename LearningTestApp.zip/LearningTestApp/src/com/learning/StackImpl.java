package com.learning;

public class StackImpl<T extends Object> {
	int top;
	T[] stkArry;
	int stackSize;
	
	public StackImpl(int sizeOfStack) {
		this.stackSize=sizeOfStack;
		stkArry = (T[]) new Object[stackSize];
		top=-1;
	}
	
	public static void main(String args[]) {
		StackImpl<Integer> st = new StackImpl<Integer>(5);
		StackImpl<String> st1 = new StackImpl<String>(3);
		try {
			st.push(10);
			st.push(20);
			//System.out.println("the top the stack is ::"+st.peek());
			System.out.println("the removed ele::"+st.pop());
			st.push(60);
			System.out.println("the top the stack is ::"+st.peek());
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		try {
			st1.push("Jeevan");
			st1.push("Borale");
			//System.out.println("the top the stack is ::"+st.peek());
			System.out.println("the removed ele::"+st1.pop());
			st1.push("Bangalore");
			System.out.println("the top the stack is ::"+st1.peek());
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
		}
			
	}
	
	public Boolean isEmpty() {
		return(top==-1);
	}
	
	public Boolean isFull() {
		return(top==stackSize-1);
	}
	
	public void push(T entry) throws Exception {
		if(isFull()) {
			throw new Exception("Stack is already full. Can not add element.");
		}
		System.out.println("the element to be inserted into stack is::"+entry);
		stkArry[++top]=entry;
	}
	
	public T pop() throws Exception {
		if(isEmpty()) {
			throw new Exception("Stack is empty. Can not remove element.");
		}
		T entry=stkArry[top--];
		System.out.println("the removed element from the stack is::"+entry);
		return entry;
		
	}
	
	public T peek() {
		return stkArry[top];
	}
	

}
