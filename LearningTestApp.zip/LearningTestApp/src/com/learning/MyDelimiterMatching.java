package com.learning;

public class MyDelimiterMatching {
	
	//{[(a+b)]}
	
	public static void main(String args[]) {
		String exp ="{a+b)}";
		MyDelimiterMatching mm = new MyDelimiterMatching();
		try {
			System.out.println(mm.delemiterMatching(exp));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Boolean delemiterMatching(String exp) throws Exception {
		int sizeofStack=exp.length();
		StackImpl<Character> st = new StackImpl<Character>(sizeofStack);
		for(int i=0;i<sizeofStack;i++) {
			char ch = exp.charAt(i);
			switch (ch) {
			case '{':
			case '[':
			case  '(':
				st.push(ch);
				break;
			case '}':
			case ']':
			case ')':
				if(!st.isEmpty()) {
					char stackContent = st.pop();
					System.out.println("the stack content is:"+stackContent);
					if((ch=='}' && stackContent!='{') ||
					(ch==')' && stackContent!='(') ||
					(ch==']' && stackContent!='[')) {
						System.out.println("mismatch found ==>"+ch+" "+"at==>"+i);
						return false;
					}
				}else {
                    System.out.println("Mismatch found: " + ch + " at " + i);
                    return false;
				}
				break;
			default:
				break;
			}
		}
		if(!st.isEmpty()) {
			System.out.println("missing the right delimiter");
			return false;
		}
		return true;
	}

}
