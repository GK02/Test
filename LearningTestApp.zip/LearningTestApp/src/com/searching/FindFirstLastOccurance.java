package com.searching;

public class FindFirstLastOccurance {
	
	public int binarySearch(int[] a,int key,boolean firstSearch) {
		int low =0;
		int high=a.length-1;
		int result=-1;
		
		while(low<=high) {
			int mid = low+(high-low)/2;
			if(key==a[mid]) {
				if(firstSearch) {
					result= mid;
					high=mid-1;
				}else {
					result= mid;
					low=mid+1;
				}
				
			}else if(key<a[mid]) {
				high=mid-1;
			}else {
				low=mid+1;
			}
		}
		
		return result;
	}
	
	public static void main(String args[]) {
		FindFirstLastOccurance ff = new FindFirstLastOccurance();
		int[] a= {10,20,30,30,30,30,30,40,50,60};
		int first = ff.binarySearch(a, 30, true);
		System.out.println("the first occurance::"+first);
		int last = ff.binarySearch(a, 30, false);
		System.out.println("the last occurance::"+last);
		int mm = (last-first)+1;
		System.out.println("no of times repeated::"+mm);
		
	}

}
