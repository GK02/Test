package com.searching;

public class BinarySearchRecursive {
	
	public int binSearch(int[] a,int low,int high,int key) {
			
		if(high>=low) {
			int mid = low+(high-low)/2;
			if(a[mid]==key) {
				return mid;
			}else if(key<a[mid]) {
				return binSearch(a,low,mid-1,key);
			}else if(key>a[mid]){
				return binSearch(a,mid+1,high,key);
			}
		}
		
		return-1;
	}
	
	public static void main(String args[]) {
		int[]a= {10,20,30,40,50};
		int n=a.length;
		BinarySearchRecursive bsr = new BinarySearchRecursive();
		int index=bsr.binSearch(a, 0, n-1, 50);
		System.out.println(index);
	}

}
